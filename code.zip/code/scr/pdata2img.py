# -*- coding: utf-8 -*-
#-------------------------------------------------
# pdata2img.py
#
# Copyright (c) 2022, National Institute for Materials Science
#-------------------------------------------------

"""
機能: 一次元NMRスペルデータ構造化　(溶液法用)
機器: AVANCE NEO 400，AVANCE III　400,500,800
rawデータ: Brukerのpdataフォルダー
設置機関： 北陸先端科学技術大学院大学

前提: Rawデータの登録を行うとともに，そのデータの識別に必要なサムネイルやメタデータを付与して
      データセット化する「データライブラリ」で取り進める
      
スクリプトの内容:    
1) Brukerのpdataフォルダー（FFT後）のデータを参照する。。
2) そのデータからスペクトルを描画し，ファイルを出力する。
"""

__author__    = "National Institute for Materials Science"
__contact__   = "MATSUNAMI.Shigeyuki@nims.go.jp"
__license__   = "ARIM Confidential"
__copyright__ = "National Institute for Materials Science, Japan"
__date__      = "2022/02/11"
__revised__   = "2022/02/11"
__version__   = "1.0A"

import os
from pathlib import Path
import numpy as np
import nmrglue as ng
from matplotlib import pyplot as plt

DATA_DIR = Path("data_org/inputdata")
OUT_DIR  = Path("data")

def make_img(data, x_scale, output_img, title, xlabel, invert_xaxis):
    """
    概要: pdataのデータ部を画像で出力する
    @param data: pdataデータ（1D numpy arrray complex128）
    @param x_scale: Xスケール（1D numpy array float）
    @param output_img: 出力ファイルパス（.png）
    @param title: 画像のタイトル（str）
    @param invert_xaxis: X軸の反転（boolean）
    @return: None
    """

    #　図の設定
    hfont = {'fontname': 'Arial'}
    fig, ax = plt.subplots(1,1, figsize=(16,9))

    # 可視化
    ax.plot(x_scale,data.real,
           color ='black',
           linewidth = 0.5
           )

    #　軸の設定
    ax.set_yticklabels([])
    
    ax.minorticks_on()
    ax.tick_params(direction = "in", 
               which = "both", 
               length = 5,
               labelsize=16)
    
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)

    ax.axes.yaxis.set_visible(False)

    # X軸を反転
    if invert_xaxis:

        ax.invert_xaxis()

    # タイトルの設定
    #ax.set_title(title,  **hfont, fontsize = 16)
    
    # X軸ラベル設定
    ax.set_xlabel(xlabel,**hfont, fontsize = 16)

    # 出力
    plt.savefig(output_img, dpi=300)
    plt.close()

def outputCSV(data, x_scale, output_csv, xunit):
    outdata = np.vstack((x_scale, data.real)).T

    if xunit == "ppm":
        header="chemical_shift, intensity"
    
    else:
        header="decay_time, intensity"
    
    np.savetxt(output_csv, outdata, header=header, 
               delimiter=",", 
               comments="", 
               encoding="utf_8")


def extract_data(pdata_file):
    """
    概要: 数値部の抽出
    @param pdata_file: pdataファイルの相対パス
    @return dataframe（メタデータ, 数値データ，x軸スケール）
    """

    # pdataデータを読み込む
    param, raw_data = ng.bruker.read_pdata(pdata_file)
    
    sw = param['procs']['SW_p']  # spectal width in Hz
    obs = param['procs']['SF']   # observation frequences in MHz
    carrier = param['procs']['OFFSET'] * obs - (sw / 2.) # carrier freq in Hz
    
    udic = ng.bruker.guess_udic(param, raw_data)
    
    udic[0]['size']     = raw_data.shape[0]
    udic[0]['complex']  = True
    udic[0]['encoding'] = 'direct'
    udic[0]['sw']       = sw
    udic[0]['obs']      = obs
    udic[0]['car']      = carrier
    udic[0]['freq']     = True
    udic[0]['time']     = False
    
    # ppmスケールの作成
    uc = ng.fileiobase.uc_from_udic(udic)
    ppm_scale = uc.ppm_scale()
   
    return param, raw_data, ppm_scale

def get_nuc (fidfile):
    """
    概要: 観測核のメタデータを抽出
    @param fidfile: fildファイルの相対パス
    @return nuc:観測核
    """
    
    param, raw_data  = ng.bruker.read(fidfile, bin_file='fid')
    nuc = str(param['acqus']['NUC1'])
    
    return nuc
    
def main():
    
    # 出力フォルダを定義し、作成する
    output_img_dir = OUT_DIR.joinpath("main_image")
    output_img_dir.mkdir(parents=True, exist_ok=True)

    output_csv_dir = OUT_DIR.joinpath("structured")
    output_csv_dir.mkdir(parents=True, exist_ok=True)

    # 1次元スペクトルのみ可視化
    
    
    for curDir, dirs, files in os.walk(DATA_DIR, topdown = True):
        
        if 'fid' in files:
            fidfile = curDir
            nuc = get_nuc (fidfile)
            
        if '1r' in files:
            print ('In progress: {}'.format(curDir))
        
            param, data, x_scale = extract_data(curDir)

            title  = curDir.split(os.sep)[2]
            
            file_num =  curDir.split(os.sep)[3]
            
            xlabel = nuc + " ppm"
            invert_xaxis = True
            
            output_img = output_img_dir.joinpath(title + '_' + file_num + ".png")
            output_csv = output_csv_dir.joinpath(title + '_' + file_num + ".csv")
            
            print (data)
            
            # CSV出力
            outputCSV(data, x_scale, output_csv, 'ppm')
            
            # 画像出力
            make_img(data, x_scale, output_img, title, xlabel, invert_xaxis)

            
        # 1ファイル目を処理したら終了
        #break

if __name__ == "__main__":
    main()
