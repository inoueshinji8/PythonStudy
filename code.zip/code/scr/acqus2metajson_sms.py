# -*- coding: utf-8 -*-
#-------------------------------------------------
# acqus2metajson.py
#
# Copyright (c) 2022, National Institute for Materials Science
#-------------------------------------------------

"""
機能: 一次元NMRスペクトルのメタデータ抽出(溶液法用)
機器: AVANCE NEO 400，AVANCE III　400,500,800
rawデータ: Brukerのacqusフォルダー
設置機関： 北陸先端科学技術大学院大学


スクリプトの内容:
acqusのメタデータ中から選定メタデータを抽出する。
"""

__author__    = "National Institute for Materials Science"
__contact__   = "MATSUNAMI.Shigeyuki@nims.go.jp"
__license__   = "ARIM Confidential"
__copyright__ = "National Institute for Materials Science, Japan"
__date__      = "2022/02/18"
__revised__   = "2022/02/18"
__version__   = "1.0"

import os
import copy
from pathlib import Path
import nmrglue as ng
from scr import rdelib as rde


DATA_DIR = Path("data_org/inputdata")
OUT_DIR  = Path("data")
METADEF_JSON = Path(__file__).parent.joinpath("metadata-def.json")
META_JSON = "metadata.json"


def get_param (fidfile):

    meta = {}
    meta, raw_data  = ng.bruker.read(fidfile, bin_file='fid')

    # D1, P1の設定
    meta['acqus']['D1'] = meta['acqus']['D'][1]
    meta['acqus']['P1'] = meta['acqus']['P'][1]

    meta_copy = copy.copy(meta)
    
    for k,v in meta_copy['acqus'].items():
       
        if isinstance(v,(str)):
            meta['acqus'][k] = [v]   
        elif isinstance(v,(int,float)):
            meta['acqus'][k] = [str(v)]
              
    return meta['acqus']

def main():
    
    # キーパラメータデータを読み込む
    metadef = rde.read_metadef(METADEF_JSON)

    # 出力フォルダを定義し、作成する
    output_metadir = OUT_DIR.joinpath("meta")
    output_metadir.mkdir(parents=True, exist_ok=True)

    # 空のメタデータを作成する
    meta = {"constant":{}, "variable":[]}

    # Brukerフォルダーのacqusフォルダーの検索
    for curDir, dirs, files in os.walk(DATA_DIR, topdown=True):
        if 'fid' in files:
            fidfile = curDir

            parm_meta = get_param (fidfile)
            filename  = curDir.split(os.sep)[2]
            
            # メタデータのconstant属性を更新する
            rde.update_metaconstant(meta, metadef, parm_meta)

            # メタデータのvariable属性を更新する
            rde.update_metavariable(meta, metadef, parm_meta)

            # メタデータの出力ファイルパスを定義する
            output_meta = output_metadir.joinpath(filename + ".json")      

            # メタデータを出力する
            rde.json_dump(meta, output_meta)

if __name__ == "__main__":
    main()
    