# -*- coding: utf-8 -*-
# -------------------------------------------------
# rdelib.py
#
# Copyright (c) 2022, National Institute for Materials Science
# -------------------------------------------------

"""
メタデータ出力に関わる共通処理モジュール
"""

__author__ = "**********"
__contact__ = "**********"
__license__ = "ARIM Confidential"
__copyright__ = "National Institute for Materials Science, Japan"
__date__ = "2022/01/27"
__revised__ = "2022/01/27"
__version__ = "1.6.0"

from datetime import datetime, timezone, timedelta
import json
import traceback
import chardet
from dateutil import parser

def preconv_datestr(datestr):
    """
    概要: 日時文字列に存在する既知の問題を修正する。
    @param datestr: 日時文字列（str）
    @return: 修正された日時文字列（str）
    """
    return datestr.replace("/ ", "/0")

def create_datetime(datestr, timestr, dateformat=None, zone=None):
    """
    概要: 日付文字列と時刻文字列からyyyy-mm-ddTHH:MM:SS+00:00形式の文字列に変換する。
          formatで日時文字列の形式を指定。
          formatを指定しない場合は自動変換。ただし失敗する可能性がある。
          引数zoneを指定するとzone付き(zone変換)で返す。
          元の文字にzoneが含まれていない場合はzone出力しない。
          また、変換できなかった場合は引数datestrをそのまま返す。
    @param datestr: 日付文字列（str）
    @param timestr: 時刻文字列（str）
    @option format: 日時文字列の形式オプション（str）
    @option zone: ゾーンオプション（boolean）
    @return: ISO8601の日時形式もしくはdatestrをそのまま返す（str）
    """
    return get_datetime(datestr + " " + timestr, dateformat=dateformat, zone=zone)


def get_datetime(datestr, dateformat=None, zone=None):
    """
    概要: 日時文字列をyyyy-mm-ddTHH:MM:SS+00:00形式の文字列に変換する。
          formatで日時文字列の形式を指定。
          formatを指定しない場合は自動変換。ただし失敗する可能性がある。
          引数zoneを指定するとzone付き(zone変換)で返す。
          元の文字にzoneが含まれていない場合はzone出力しない。
          また、変換できなかった場合は引数datestrをそのまま返す。
    @param datestr: 日時文字列（str）
    @option format: 日時文字列の形式オプション（str）
    @option zone: ゾーンオプション（boolean）
    @return: ISO8601の日時形式もしくはdatestrをそのまま返す（str）
    """
    try:
        # 文字列をdatetime型に変換
        # dateformatが指定されている場合
        if dateformat:
            d = datetime.strptime(datestr, dateformat)
        else:
            d = parser.parse(preconv_datestr(datestr))

        # zoneフラグがTrueの場合
        if zone:
            # もとの文字列にtimezoneが含まれていない場合
            if d.tzinfo is None:
                d = d.replace(tzinfo=timezone(timedelta(hours=9)))

        # zoneフラグがFalseの場合
        else:
            # timezoneを取り除く
            d = d.replace(tzinfo=None)

        # ISO8601の文字列に変換する
        d = d.isoformat(timespec="seconds")

    except Exception as e:
        print(e)
        # traceback.print_exc()
        d = None
    return d


def get_date(datestr):
    """
    概要: 日時文字列からyyyy-mm-ddを返す。
          変換できなかった場合はNoneを返す。
    @param datestr: 日時文字列（str）
    @return: yyyy-mm-dd形式もしくはNone（str）
    """
    try:
        # 文字列を日時に変換してからyyyy-mm-ddに変換する
        d = parser.parse(preconv_datestr(datestr)).strftime("%Y-%m-%d")
    except Exception as e:
        print(e)
        # traceback.print_exc()
        d = None
    return d


def get_time(datestr):
    """
    概要: 日時文字列からHH:MM:SSを返す。
          変換できなかった場合はNoneを返す。
    @param datestr: 日時文字列（str）
    @return: HH:MM:SS形式もしくはNone（str）
    """
    try:
        # 文字列を日時に変換してからHH:MM:SSに変換する
        d = parser.parse(preconv_datestr(datestr)).strftime("%H:%M:%S")
    except Exception as e:
        print(e)
        # traceback.print_exc()
        d = None
    return d


def csv_dump(datalist, metadef, filepath, enc="utf_8"):
    """
    概要: リストデータをCSVで出力する
    @param datalist: リストデータ（list）
    @param metadef: メタデータ定義ファイル（dict）
    @param filepath: 出力ファイルパス（.csv）
    @return: None
    """
    metadef_keys = list(metadef.keys())
    with open(filepath, "w", encoding=enc) as f:
        f.write(",".join(metadef_keys) + "\n")
        for d in datalist:
            f.write(",".join([str(d[k]) for k in metadef_keys]) + "\n")


def json_dump(datadict, filepath, enc="utf_8"):
    """
    概要: 辞書データをJSONで出力する
    @param datadict: 辞書データ（dict）
    @param filepath: 出力ファイルパス（.json）
    @return: None
    """
    with open(filepath, "w", encoding=enc) as f:
        json.dump(datadict, f, indent=4, ensure_ascii=False)


def get_metavalue(meta, metadef):
    """
    概要: メタデータからvalueだけを読みだす
    @param meta: メタデータ（dict）
    @param metadef: メタデータ定義データ（dict）
    @return: メタデータのvalue（dict）
    """
    meta_values = {}
    for k in metadef:
        if metadef[k].get("variable") is None:
            v = meta["constant"].get(k)
        else:
            v = meta["variable"][0].get(k)

        if v is None:
            value = ""
        else:
            value = v["value"]

        meta_values[k] = value
    return meta_values


def is_float(value):
    """
    概要: valueがFloat型に変換できるか確認する
    @param value: 値（object）
    @return: boolean
    """
    isfloat = True
    try:
        value = float(value)
    except:
        isfloat = False
    return isfloat


def split_num_unit(value):
    """
    概要: 文字列から数値と単位を分離する
    @param value: 値（str）
    @return: 数値（str）, 単位（str）
    """
    v = ""
    u = ""
    for s in str(value):
        if s in "0123456789.E+-":
            v += s
        else:
            u += s
    return v.strip(), u.strip()


def convert_value(metadef, key, value):
    """
    概要: 値の文字列を形式変換する
    @param metadef: メタデータ定義ファイル（dict）
    @param key: メタデータのパラメータ名（str）
    @param value: データの値（str）
    @return: 値
    """
    vtype = metadef[key]["schema"].get("type")
    vfmt = metadef[key]["schema"].get("format")
    if vtype == "array":
        cvalue = value
    elif vtype == "boolean":
        v = str(value).lower()
        if v == "true":
            cvalue = True
        elif v == "false":
            cvalue = False
        else:
            print(
                "[警告] schema/typeが間違っています。",
                key + "のメタ定義:" + vtype,
                " 実際の値:" + str(value),
            )
            cvalue = v
    elif vtype == "integer":
        v, u = split_num_unit(value)
        if v.isdigit():
            cvalue = int(v)
        else:
            print(
                "[警告] schema/typeが間違っています。",
                key + "のメタ定義:" + vtype,
                " 実際の値:" + str(value),
            )
            cvalue = v
    elif vtype == "number":
        v, u = split_num_unit(value)
        if is_float(v):
            cvalue = float(v)
        else:
            print(
                "[警告] schema/typeが間違っています。",
                key + "のメタ定義:" + vtype,
                " 実際の値:" + str(value),
            )
            cvalue = v
    elif vtype == "string":
        if vfmt:
            if vfmt == "date-time":
                cvalue = get_datetime(value)
            elif vfmt == "date":
                cvalue = get_date(value)
            elif vfmt == "time":
                cvalue = get_time(value)
        else:
            cvalue = str(value)
    else:
        cvalue = str(value)
    return cvalue


def add_metaitem(meta, metadef, datadict, key, value, n=None):
    """
    概要: メタデータにアイテムを追加する
    @param meta: メタデータ（dict）
    @param metadef: メタデータ定義ファイル（dict）
    @param datadict: 辞書データ（dict）
    @param key: メタデータのパラメータ名（str）
    @param value: データの値（str）
    @return: None
    """
    if n is None:
        meta["constant"][key] = {}
        mi = meta["constant"][key]
        unitidx = 0
    else:
        meta["variable"][n][key] = {}
        mi = meta["variable"][n][key]
        unitidx = n

    mi["value"] = convert_value(metadef, key, value)
    unit = metadef[key].get("unit")
    if unit:
        if unit.startswith("$"):
            unit = datadict.get(unit[1:])
            if unit:
                mi["unit"] = unit[unitidx]
        else:
            mi["unit"] = unit


def update_metavariable(meta, metadef, datadict, ignore_action=False):
    """
    概要: メタデータのvariable属性を更新する
    @param meta: メタデータ（dict）
    @param metadef: メタデータ定義ファイル（dict）
    @param datadict: 辞書データ（dict）
    @return: None
    """
    max_variable = len(max(datadict.values(), key=lambda x: len(x)))

    for k in metadef:
        if metadef[k].get("variable") is None:
            continue

        action = metadef[k].get("action")
        if ignore_action or (action is None):
            value = datadict.get(k)
            if value:
                for i, v in enumerate(value):
                    if i == len(meta["variable"]):
                        meta["variable"].append({})
                    add_metaitem(meta, metadef, datadict, k, v, n=i)
        else:
            action = str(action)
            for i in range(max_variable):
                if i == len(meta["variable"]):
                    meta["variable"].append({})
                v = eval_action(action, datadict, i)
                add_metaitem(meta, metadef, datadict, k, v, n=i)


def update_metaconstant(meta, metadef, datadict, ignore_action=False):
    """
    概要: メタデータのconstant属性を更新する
    @param meta: メタデータ（dict）
    @param metadef: メタデータ定義ファイル（dict）
    @param datadict: 辞書データ（dict）
    @return: None
    """
    for k in metadef:
        if metadef[k].get("variable") is not None:
            continue

        action = metadef[k].get("action")
        if ignore_action or (action is None):
            value = datadict.get(k)
            if value:
                v = value[0]
                add_metaitem(meta, metadef, datadict, k, v)
        else:
            action = str(action)
            v = eval_action(action, datadict)
            add_metaitem(meta, metadef, datadict, k, v)


def eval_action(action, datadict, n=None):
    """
    概要: actionに従い値を計算する
    @param action: actionの計算式（str）
    @param datadict: 辞書データ（dict）
    @param n: 要素番号（int）
    @return: eval結果
    """
    for k in datadict:
        # データのパラメータ名に一致した場合に処理
        if k in action:
            if n is None:
                v = datadict.get(k)[0]
            else:
                v = datadict.get(k)[n]

            for d in list(globals().keys()):
                # rdelibモジュールの関数に含まれている場合
                if d in action:
                    # 関数の引数なので""を付与する
                    action = action.replace(k, '"' + v + '"')
                    break
            else:
                action = action.replace(k, v)
    return eval(action)


def get_encoding(filepath):
    """
    概要: ファイルのエンコーディングを取得する
    @param filepath: ファイルパス
    @return: エンコーディング（str）
    """
    return chardet.detect(open(filepath, "rb").read())["encoding"]


def read_metadef(filepath):
    """
    概要: メタデータ定義ファイルを読み込む
    @param filepath: ファイルパス
    @return: メタデータ定義データ（dict）
    """

    # ファイルがない場合は終了する
    if not filepath.exists():
        print(str(filepath) + "がありません。終了します。")
        exit()

    # メタデータ定義ファイルを読む
    with open(filepath, "r", encoding=get_encoding(filepath)) as f:
        metadef = json.load(f)
    return metadef
