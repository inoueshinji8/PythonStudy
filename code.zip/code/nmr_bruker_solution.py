# -*- coding: utf-8 -*-
#-------------------------------------------------
# nmr_bruker_solution.py
#
# Copyright (c) 2022, National Institute for Materials Science
#-------------------------------------------------

"""
機能: 一次元NMRスペルデータ構造化　(溶液法用)
機器: AVANCE NEO 400，AVANCE III　400,500,800 
rawデータ: Brukerのpdataフォルダー
設置機関： 北陸先端科学技術大学院大学

スクリプトの内容:    
1) Brukerのpdataフォルダー（FFT後）のデータを参照する。
2) そのデータからスペクトルの数値データならびにpngファイルを出力する。
3) 選定メタデータをjson形式で出力する。
"""

__author__    = "National Institute for Materials Science"
__contact__   = "MATSUNAMI.Shigeyuki@nims.go.jp"
__license__   = "ARIM Confidential"
__copyright__ = "National Institute for Materials Science, Japan"
__date__      = "2022/02/18"
__revised__   = "2022/02/18"
__version__   = "1.0"


from scr import pdata2img,acqus2metajson

def main ():

    pdata2img.main()        # スペクトル図の作成
    acqus2metajson.main()   # 溶液向けメタデータの選定
    
if __name__ == "__main__":
    main()